class Computer():
    def __init__(self, id: int):
        self.id = id
        self.serial_number = "A"
        self.brand = "B"
        self.model = "C"
        self.mac_address = "D"
        self.arrival_date = "E"
        self.departure_date = "F"
        self.recipient = "G"
        self.status = "H"