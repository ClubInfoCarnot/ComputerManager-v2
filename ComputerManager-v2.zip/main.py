import sanic
import sanic.response
import dotenv
from routes.index import index

dotenv.load_dotenv(".env")

app = sanic.Sanic(name="ComputerManager-v2")

@app.route('/')
async def test(request):
    return sanic.response.html(index())

@app.route(name='/styles/<filename>', uri='/styles/<filename>')
async def test(request, filename):
    return await sanic.response.file(f'styles/{filename}')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)