from core.computer import Computer

def index():
    return f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="styles/style.css">
        <link rel="stylesheet" href="styles/computers.css">
        <title>Ordinateurs</title>
    </head>
    <body>

        <section class="research">
            <h2 class="research-h2">Recherche</h2>
            <div class="research-div">
                <input type="text" name="research" id="research" class=research-input>
                <a href="#" action="">Rechercher</a>
            </div>
        </section>

        <section class="result">
            <table class="computer-result-table">
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">N° de série</th>
                    <th scope="col">Marque</th>
                    <th scope="col">Modèle</th>
                    <th scope="col">Adresse MAC</th>
                    <th scope="col">Arrivée</th>
                    <th scope="col">Départ</th>
                    <th scope="col">Destinataire</th>
                    <th scope="col">Status</th>
                </tr>
                {
                    fill_tab()
                }
            </table>
        </section>
        
    </body>
    </html>
    """

def fill_tab():
    computers = [
        Computer(1),
        Computer(2),
        Computer(3),
        Computer(4),
        Computer(5),
        Computer(6),
        Computer(7),
        Computer(8),
        Computer(9),
        Computer(10),
    ]
    value = ""
    for computer in computers:
        value = value + f"""
        <tr>
            <td>{computer.id}</td>
            <td>{computer.serial_number}</td>
            <td>{computer.brand}</td>
            <td>{computer.model}</td>
            <td>{computer.mac_address}</td>
            <td>{computer.arrival_date}</td>
            <td>{computer.departure_date}</td>
            <td>{computer.recipient}</td>
            <td>{computer.status}</td>
        </tr>
        """
    return value